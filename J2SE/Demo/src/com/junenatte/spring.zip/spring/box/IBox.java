package com.junenatte.spring.box;

public interface IBox {
    String getIntColor();
}
