package com.junenatte.spring.paper;

public interface IPaper {
    String getPaperName();
}
